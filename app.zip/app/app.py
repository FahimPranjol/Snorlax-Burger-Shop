# IMPORTS #
import sys
sys.path.insert(0, '/var/www/html')

from flask import Flask, render_template, request, session, make_response
from models import Staff, Menu, MenuItem, Orders
from bson import ObjectId
import datetime

# Application #
application = Flask(__name__)
application.debug = True


# Filters #
@application.template_filter('datetimeformat')
def datetimeformat(value, fmt='%m/%d/%Y %H:%M:%S'):
    return datetime.datetime.fromtimestamp(value).strftime(fmt)


# Routes #
@application.route("/")
def index():
    return render_template("index.html")


@application.route("/reports", methods=['POST', 'GET'])
def reports():
    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('type', None) is not None and request.form.get('type', None) == 'day':
            # Get the orders
            orders = Orders.get_for_date(request.form['date'])
        elif request.form.get('type', None) is not None and request.form.get('type', None) == 'range':
            # Get the orders
            orders = Orders.get_for_range(request.form['start'], request.form['end'])
    elif request.method == 'GET':
        # Nothing to but show the form
        orders = []

    return render_template("reports.html", orders=orders)


@application.route("/staff", methods=['POST', 'GET'])
@application.route("/staff/edit/<string:internal_id>", methods=['GET'])
@application.route("/staff/delete/<string:internal_id>", methods=['GET'])
def staff(internal_id=None):
    # Set the form success to false by default
    add_success = False
    edit_success = False
    delete_success = False
    current = None
    edit = False

    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('_id', None) is not None:
            # Handle item update
            person = Staff(request.form['id'], request.form['firstname'], request.form['lastname'], False)
            update_count = person.update(request.form['_id'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        elif request.form.get('staff_id', None) is not None:
            # Handle item update
            update_count = Staff.assign_tables(request.form['staff_id'], request.form['date'], request.form['tables'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        else:
            # Handle item insertion
            person = Staff(request.form['id'], request.form['firstname'], request.form['lastname'], True)
            db_insert_id = person.insert()

            # Make sure we got a valid insert id
            if ObjectId.is_valid(db_insert_id):
                # Set the form success in this case
                add_success = True
    elif request.method == 'GET':
        # Check if we are edit or delete mode
        if 'delete' in request.path.split('/'):
            # Request the delete
            delete_count = Staff.delete(internal_id)

            # Check if we deleted and set the success flag
            if delete_count == 1:
                # Set the flag
                delete_success = True
        elif 'edit' in request.path.split('/'):
            # Set the edit
            edit = True

            # Check if we have an edit or delete
            if internal_id is not None:
                # Let us get this item from the database first
                current = Staff.get(internal_id)

    # Query the database for results
    count, staff = Staff.get_all()

    # Return the data
    return render_template("staff.html", add_success=add_success, edit_success=edit_success, delete_success=delete_success, count=count, staff=staff, edit=edit, current=current)


@application.route("/menu", methods=['POST', 'GET'])
@application.route("/menu/edit/<string:internal_id>", methods=['GET'])
@application.route("/menu/delete/<string:internal_id>", methods=['GET'])
def menu(internal_id=None):
    # Set the form success to false by default
    add_success = False
    edit_success = False
    delete_success = False
    current = None
    edit = False

    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('_id', None) is not None:
            # Handle item update
            item = MenuItem(request.form['name'], request.form['price'], request.form['ingredients'], request.form['calories'], request.form['description'])
            update_count = item.update(request.form['_id'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        else:
            # Handle item insertion
            item = MenuItem(request.form['name'], request.form['price'], request.form['ingredients'], request.form['calories'], request.form['description'])
            db_insert_id = item.insert()

            # Make sure we got a valid insert id
            if ObjectId.is_valid(db_insert_id):
                # Set the form success in this case
                add_success = True
    elif request.method == 'GET':
        # Check if we are edit or delete mode
        if 'delete' in request.path.split('/'):
            # Request the delete
            delete_count = MenuItem.delete(internal_id)

            # Check if we deleted and set the success flag
            if delete_count == 1:
                # Set the flag
                delete_success = True
        elif 'edit' in request.path.split('/'):
            # Set the edit
            edit = True

            if internal_id is not None:
                # Let us get this item from the database first
                current = Menu.get_item(internal_id)

    # Query the database for results
    count, items = Menu.get_items()

    # Return the data
    return render_template("menu.html", add_success=add_success, edit_success=edit_success, delete_success=delete_success, count=count, items=items, edit=edit, current=current)


@application.route("/comps", methods=['GET'])
def comps():
    # Get the orders which have comped items
    comps = Orders.get_comped()

    return render_template("comps.html", comps=comps)


# MAIN #
if __name__ == "__main__":
    application.run()
