# IMPORTS #
from bson import ObjectId
import datetime
from flaskapp.common.database import Database

# Staff #
class Staff(object):
    def __init__(self, unique_id, firstname, lastname, first_create):
        # Set up the attributes
        self.id = unique_id
        self.firstname = firstname
        self.lastname = lastname

        # Only do this new instances
        if first_create:
            self.tables = []

    @classmethod
    def get_all(cls):
        # Let us query the database for staff
        count = Database.DATABASE.staff.count()

        # Check if we have something, otherwise empty array
        if count > 0:
            # Return the query object
            return count, Database.DATABASE.staff.find()
        else:
            # Return an empty array
            return 0, []

    @classmethod
    def get(cls, _id):
        # Get the single item identified by the id
        return Database.DATABASE.staff.find_one({'_id': ObjectId(_id)})

    def insert(self):
        # Insert this object in to the database
        return Database.DATABASE.staff.insert_one(vars(self)).inserted_id

    def update(self, _id):
        # Insert this object in to the database
        return Database.DATABASE.staff.update_one({'_id': ObjectId(_id)}, {'$set': vars(self)}).modified_count

    @staticmethod
    def delete(_id):
        # Insert this object in to the database
        return Database.DATABASE.staff.delete_one({'_id': ObjectId(_id)}).deleted_count

    @staticmethod
    def assign_tables(_id, date, tables):
        # Insert this object in to the database
        return Database.DATABASE.staff.update_one({'_id': ObjectId(_id)}, {'$push': {'tables': {date: tables}}}, True).modified_count


# Menu #
class Menu(object):
    @classmethod
    def get_items(cls):
        # Let us query the database for menu items
        items_count = Database.DATABASE.menu.count()

        # Check if we have something, otherwise empty array
        if items_count > 0:
            # Return the query object
            return items_count, Database.DATABASE.menu.find()
        else:
            # Return an empty array
            return 0, []

    @classmethod
    def get_item(cls, _id):
        # Get the single item identified by the id
        return Database.DATABASE.menu.find_one({'_id': ObjectId(_id)})


# Menu Item #
class MenuItem(object):
    def __init__(self, name, price, ingredients, calories, description):
            # Set up the attributes
            self.name = name
            self.price = price
            self.ingredients = ingredients
            self.calories = calories
            self.description = description

    def insert(self):
        # Insert this object in to the database
        return Database.DATABASE.menu.insert_one(vars(self)).inserted_id

    def update(self, _id):
        # Insert this object in to the database
        return Database.DATABASE.menu.update_one({'_id': ObjectId(_id)}, {'$set': vars(self)}).modified_count

    @staticmethod
    def delete(_id):
        # Insert this object in to the database
        return Database.DATABASE.menu.delete_one({'_id': ObjectId(_id)}).deleted_count


# Order #
class Orders(object):
    @staticmethod
    def get_for_date(report_date):
        # Convert to the start of the start date
        temp_startdate = datetime.datetime.strptime(report_date, "%m/%d/%Y")
        final_startdate = temp_startdate.replace(hour=0, minute=0, second=0)
        final_enddate = temp_startdate.replace(hour=23, minute=59, second=59)

        # Let us query the database for menu items
        orders = Database.DATABASE.orders.find({'datetime': {'$gte': final_startdate.timestamp(), '$lte': final_enddate.timestamp()}})

        # Return the order retrieved
        return list(orders)

    @staticmethod
    def get_for_range(startdate, enddate):
        # Convert to the start of the start date
        temp_startdate = datetime.datetime.strptime(startdate, "%m/%d/%Y")
        final_startdate = temp_startdate.replace(hour=0, minute=0, second=0)

        # Convert to the end of the end date
        temp_enddate = datetime.datetime.strptime(enddate, "%m/%d/%Y")
        final_enddate = temp_enddate.replace(hour=23, minute=59, second=59)

        # Let us query the database for menu items
        orders = Database.DATABASE.orders.find({'datetime': {'$gte': final_startdate.timestamp(), '$lte': final_enddate.timestamp()}})

        # Return the order retrieved
        return list(orders)

    @staticmethod
    def get_comped():
        # Let us query the database for menu items
        orders = Database.DATABASE.orders.find({'items.comped': True})

        # Return the order retrieved
        return list(orders)
