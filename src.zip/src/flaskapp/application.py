import sys
from flaskapp.common.database import Database
from flaskapp.models.blog import Blog
from flaskapp.models.post import Post
from flaskapp.models.user import User

from flaskapp.models.manager import Staff, Menu, MenuItem, Orders
from bson import ObjectId
import datetime

__author__ = 'jslvtr'

from flask import Flask, render_template, request, session, make_response

app = Flask(__name__, static_folder="assets")  # '__main__'
app.secret_key = "secure"

# Filters #
@app.template_filter('datetimeformat')
def datetimeformat(value, fmt='%m/%d/%Y %H:%M:%S'):
    return datetime.datetime.fromtimestamp(value).strftime(fmt)


@app.route('/login')  # www.mysite.com/api/
def login_template():
    return render_template('login.html')


@app.route('/register')
def register_template():
    return render_template('register.html')


@app.before_first_request
def initialize_database():
    Database.initialize()


@app.route('/auth/login', methods=['POST'])
def login_user():
    email = request.form['email']
    password = request.form['password']

    if User.login_valid(email, password):
        User.login(email)
    else:
        session['email'] = None

        return render_template("profile.html", email=session['email'])


@app.route('/auth/register', methods=['POST'])
def register_user():
    email = request.form['email']
    password = request.form['password']

    User.register(email, password)

    return render_template("profile.html", email=session['email'])


@app.route('/blogs/string<string:user_id>')
@app.route('/blogs')
def user_blogs(user_id=None):
    if user_id is not None:
        user = User.get_by_id(user_id)
    else:
        user = User.get_by_email(session['email'])

    blogs = user.get_blogs()

    return render_template("user_blogs.html", blogs=blogs, email=user.email)

@app.route('/blogs/new', methods=['POST','GET'])
def create_new_blog():
    if request.method == 'GET':
        return render_template('new_blog.html')
    else:
        title = request.form['title']
        description = request.form['description']
        user = User.get_by_email(session['email'])

        new_blog = Blog(user.email, title, description, user._id)
        new_blog.save_to_mongo()

        return make_response(user_blogs(user.id))

@app.route('/posts/<string:blog_id>')
def blog_posts(blog_id):
    blog = Blog.from_mongo(blog_id)
    posts = blog.get_posts()

    return render_template('post.html', posts=posts, blog_title=blog.title, blog_id=blog.id)

@app.route('/posts/new/<string:blog_id>', methods=['POST','GET'])
def create_new_post(blog_id):
    if request.method == 'GET':
        return render_template('new_post.html')
    else:
        title = request.form['title']
        content = request.form['content']
        user = User.get_by_email(session['email'])

        new_post = Post(blog_id, title, content, user.email)
        new_post.save_to_mongo()

        return make_response(blog_posts(blog_id))


@app.route("/reports", methods=['POST', 'GET'])
def reports():
    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('type', None) is not None and request.form.get('type', None) == 'day':
            # Get the orders
            orders = Orders.get_for_date(request.form['date'])
        elif request.form.get('type', None) is not None and request.form.get('type', None) == 'range':
            # Get the orders
            orders = Orders.get_for_range(request.form['start'], request.form['end'])
    elif request.method == 'GET':
        # Nothing to but show the form
        orders = []

    return render_template("reports.html", orders=orders)


@app.route("/staff", methods=['POST', 'GET'])
@app.route("/staff/edit/<string:internal_id>", methods=['GET'])
@app.route("/staff/delete/<string:internal_id>", methods=['GET'])
def staff(internal_id=None):
    # Set the form success to false by default
    add_success = False
    edit_success = False
    delete_success = False
    current = None
    edit = False

    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('_id', None) is not None:
            # Handle item update
            person = Staff(request.form['id'], request.form['firstname'], request.form['lastname'], False)
            update_count = person.update(request.form['_id'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        elif request.form.get('staff_id', None) is not None:
            # Handle item update
            update_count = Staff.assign_tables(request.form['staff_id'], request.form['date'], request.form['tables'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        else:
            # Handle item insertion
            person = Staff(request.form['id'], request.form['firstname'], request.form['lastname'], True)
            db_insert_id = person.insert()

            # Make sure we got a valid insert id
            if ObjectId.is_valid(db_insert_id):
                # Set the form success in this case
                add_success = True
    elif request.method == 'GET':
        # Check if we are edit or delete mode
        if 'delete' in request.path.split('/'):
            # Request the delete
            delete_count = Staff.delete(internal_id)

            # Check if we deleted and set the success flag
            if delete_count == 1:
                # Set the flag
                delete_success = True
        elif 'edit' in request.path.split('/'):
            # Set the edit
            edit = True

            # Check if we have an edit or delete
            if internal_id is not None:
                # Let us get this item from the database first
                current = Staff.get(internal_id)

    # Query the database for results
    count, staff = Staff.get_all()

    # Return the data
    return render_template("staff.html", add_success=add_success, edit_success=edit_success, delete_success=delete_success, count=count, staff=staff, edit=edit, current=current)


@app.route("/menu", methods=['POST', 'GET'])
@app.route("/menu/edit/<string:internal_id>", methods=['GET'])
@app.route("/menu/delete/<string:internal_id>", methods=['GET'])
def menu(internal_id=None):
    # Set the form success to false by default
    add_success = False
    edit_success = False
    delete_success = False
    current = None
    edit = False

    # Check if we have a post
    if request.method == 'POST':
        # Check if we are in edit mode or add mode
        if request.form.get('_id', None) is not None:
            # Handle item update
            item = MenuItem(request.form['name'], request.form['price'], request.form['ingredients'], request.form['calories'], request.form['description'])
            update_count = item.update(request.form['_id'])

            # Make sure we got a valid insert id
            if update_count >= 1:
                # Set the form success in this case
                edit_success = True
        else:
            # Handle item insertion
            item = MenuItem(request.form['name'], request.form['price'], request.form['ingredients'], request.form['calories'], request.form['description'])
            db_insert_id = item.insert()

            # Make sure we got a valid insert id
            if ObjectId.is_valid(db_insert_id):
                # Set the form success in this case
                add_success = True
    elif request.method == 'GET':
        # Check if we are edit or delete mode
        if 'delete' in request.path.split('/'):
            # Request the delete
            delete_count = MenuItem.delete(internal_id)

            # Check if we deleted and set the success flag
            if delete_count == 1:
                # Set the flag
                delete_success = True
        elif 'edit' in request.path.split('/'):
            # Set the edit
            edit = True

            if internal_id is not None:
                # Let us get this item from the database first
                current = Menu.get_item(internal_id)

    # Query the database for results
    count, items = Menu.get_items()

    # Return the data
    return render_template("menu.html", add_success=add_success, edit_success=edit_success, delete_success=delete_success, count=count, items=items, edit=edit, current=current)


@app.route("/comps", methods=['GET'])
def comps():
    # Get the orders which have comped items
    comps = Orders.get_comped()

    return render_template("comps.html", comps=comps)
