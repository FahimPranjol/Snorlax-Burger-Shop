# Import the application
from flaskapp.application import app
app.run(debug=True)